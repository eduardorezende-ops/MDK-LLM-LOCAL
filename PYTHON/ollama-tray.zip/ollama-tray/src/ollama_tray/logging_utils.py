from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from .config import get_app_dir, get_log_path


def setup_logging() -> None:
    app_dir = get_app_dir()
    app_dir.mkdir(parents=True, exist_ok=True)

    log_path = get_log_path()

    root = logging.getLogger()
    root.setLevel(logging.INFO)

    # Evita duplicar handlers em reexecuções (PyInstaller pode importar de novo em alguns casos)
    if any(isinstance(h, RotatingFileHandler) for h in root.handlers):
        return

    handler = RotatingFileHandler(
        log_path,
        maxBytes=512_000,
        backupCount=3,
        encoding="utf-8",
    )
    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
    handler.setFormatter(formatter)
    root.addHandler(handler)

