from __future__ import annotations

import logging
import os
import shutil
import subprocess
import time
import urllib.error
import urllib.request
from dataclasses import dataclass


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class OllamaStatus:
    running: bool
    base_url: str
    started_by_app: bool


def _test_ollama(base_url: str) -> bool:
    url = base_url.rstrip("/") + "/api/tags"
    try:
        with urllib.request.urlopen(url, timeout=3) as resp:
            return 200 <= resp.status < 300
    except (urllib.error.URLError, TimeoutError, ValueError):
        return False


def _resolve_ollama_path(configured_path: str | None) -> str:
    if configured_path and os.path.exists(configured_path):
        return configured_path

    in_path = shutil.which("ollama")
    if in_path:
        return in_path

    localappdata = os.environ.get("LOCALAPPDATA")
    if localappdata:
        fallback = os.path.join(localappdata, "Programs", "Ollama", "ollama.exe")
        if os.path.exists(fallback):
            return fallback

    raise FileNotFoundError(
        "Não encontrei o executável do Ollama (ollama.exe). "
        "Instale o Ollama ou aponte o caminho nas Configurações."
    )


class OllamaManager:
    def __init__(self, base_url: str, ollama_path: str | None):
        self.base_url = base_url
        self.ollama_path = ollama_path
        self._process: subprocess.Popen[bytes] | None = None
        self._started_by_app = False

    def status(self) -> OllamaStatus:
        running = _test_ollama(self.base_url)
        return OllamaStatus(running=running, base_url=self.base_url, started_by_app=self._started_by_app)

    def ensure_running(self, timeout_sec: int = 30) -> None:
        if _test_ollama(self.base_url):
            logger.info("Ollama já está respondendo em %s", self.base_url)
            return

        self.start()

        deadline = time.time() + timeout_sec
        while time.time() < deadline:
            if _test_ollama(self.base_url):
                logger.info("Ollama OK em %s", self.base_url)
                return
            time.sleep(1)

        raise TimeoutError(
            f"Ollama não subiu em tempo. Verifique o serviço/porta e tente novamente. URL: {self.base_url}"
        )

    def start(self) -> None:
        if _test_ollama(self.base_url):
            logger.info("Start ignorado: Ollama já está rodando.")
            return

        exe = _resolve_ollama_path(self.ollama_path)
        logger.info("Iniciando Ollama: %s serve", exe)

        creationflags = 0
        if os.name == "nt" and hasattr(subprocess, "CREATE_NO_WINDOW"):
            creationflags = subprocess.CREATE_NO_WINDOW  # type: ignore[attr-defined]

        # stdout/stderr ficam no log do próprio Ollama (quando ele gerencia como serviço),
        # então aqui a gente só mantém o processo vivo.
        self._process = subprocess.Popen(  # noqa: S603,S607
            [exe, "serve"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
        )
        self._started_by_app = True

    def stop(self, timeout_sec: int = 5) -> None:
        if not self._started_by_app:
            raise RuntimeError("Não vou parar o Ollama porque ele não foi iniciado por este app.")

        if not self._process:
            raise RuntimeError("Processo do Ollama não está disponível para encerrar.")

        if self._process.poll() is not None:
            logger.info("Processo do Ollama já terminou.")
            return

        logger.info("Encerrando Ollama (pid=%s)...", self._process.pid)
        self._process.terminate()
        try:
            self._process.wait(timeout=timeout_sec)
        except subprocess.TimeoutExpired:
            logger.warning("Terminate não respondeu; forçando kill...")
            self._process.kill()
            self._process.wait(timeout=timeout_sec)

