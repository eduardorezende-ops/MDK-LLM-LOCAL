from __future__ import annotations

import sys
from pathlib import Path

# Garante que o diretório "src" esteja no sys.path ao rodar via:
#   python src\main.py
sys.path.insert(0, str(Path(__file__).resolve().parent))

from ollama_tray.app import run_app  # noqa: E402


if __name__ == "__main__":
    run_app()
