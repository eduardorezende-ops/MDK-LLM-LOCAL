@echo off
setlocal

REM Build do executável (Windows)
REM Saída: dist\OllamaTray.exe

pyinstaller ^
  --noconsole ^
  --onefile ^
  --name OllamaTray ^
  --clean ^
  src\main.py

echo.
echo Build finalizado. Veja: dist\OllamaTray.exe
endlocal

